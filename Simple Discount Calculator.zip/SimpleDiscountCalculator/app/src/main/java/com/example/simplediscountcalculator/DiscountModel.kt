package com.example.simplediscountcalculator

import androidx.lifecycle.ViewModel

class DiscountModel: ViewModel() {
    var saveAmount = "0.00 $"
    var taxAmount = "0.00 $"
    var totalAmount = "0.00 $"
}